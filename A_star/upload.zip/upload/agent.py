from __future__ import annotations
from board import Board
from collections.abc import Callable
from queue import PriorityQueue
import numpy as np


def MT(board: Board) -> int:
    h = 0
    for i in range(3):
        for j in range(3):
            if board.state[i][j] != 0 and board.state[i][j] != board.solution[i][j]:
                h += 1
    return h


def CB(board: Board) -> int:
    '''
    Counts the number of conflicts in the board's rows and columns
    '''
    n = board.state.shape[0]
    total_conflicts = 0
    
    for i in range(n):
        row = board.state[i]
        col = board.state[:, i]
        
        # Count conflicts in row
        row_conflicts = 0
        for j in range(n):
            if row[j] != 0:
                for k in range(j + 1, n):
                    if row[k] != 0 and row[j] > row[k]:
                        row_conflicts += 1
        
        # Count conflicts in column
        col_conflicts = 0
        for j in range(n):
            if col[j] != 0:
                for k in range(j + 1, n):
                    if col[k] != 0 and col[j] > col[k]:
                        col_conflicts += 1
        
        # Add total conflicts for row and column to total conflicts for board
        total_conflicts += row_conflicts + col_conflicts
    
    return total_conflicts



def NA(board: Board) -> int:

    def count_conflicts(board_row):
        conflicts = 0
        max_val = -1
        for i in range(len(board_row)):
            if board_row[i] == 0:
                continue
            if board_row[i] > max_val:
                max_val = board_row[i]
            else:
                for j in range(i + 1, len(board_row)):
                    if board_row[j] == 0:
                        continue
                    if board_row[j] == max_val:
                        break
                    if board_row[j] < max_val and board_row[j] > board_row[i]:
                        conflicts += 1
        return conflicts
    h = 0
    for i in range(3):
        h += count_conflicts(board.state[i, :])
        h += count_conflicts(board.state[:, i])
    return h + CB(board)


def BF(board: Board) -> int:
    
    return 0

'''
A* Search 
'''


def a_star_search(board: Board, heuristic: Callable[[Board], int]):
    frontier = PriorityQueue()
    frontier.put((heuristic(board), board))
    visited = set()
    num_node = 0
    #times = 100

    while not frontier.empty():# and times > 0:
        _, current_state = frontier.get()

        visited.add(tuple(map(tuple, current_state.state)))
        
        next_states = current_state.next_action_states()

        for next_state, action in next_states:
            next_state.nodes =  next_state.nodes + 1
            num_node = num_node +1
            if tuple(map(tuple, current_state.state)) == tuple(map(tuple, current_state.solution)):
                return (current_state.total_action,num_node)

            if tuple(map(tuple, next_state.state)) not in visited:
                # Calculate the cost of the next state
                cost = current_state.g + heuristic(next_state)
                frontier.put((cost, next_state))
                next_state.g = current_state.g + 1
                next_state.total_action.append(action)

        #times = times - 1

    return None